exports.addition = function (a,b) {
    return a+b;
};